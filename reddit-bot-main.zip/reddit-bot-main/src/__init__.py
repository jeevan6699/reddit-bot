"""Package initialization file."""

__version__ = "1.0.0"
__author__ = "bot-monitor"
__description__ = "A sophisticated Reddit bot that monitors subreddits and responds naturally using LLMs"